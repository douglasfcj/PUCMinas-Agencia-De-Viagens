# Agência de Viagens

Este projeto tem por finalidade entender e propor melhorias nos processos desenvolvidos na comercialização de produtos e seus desafios diante das novas tecnologias e do novo cenário pós-pandemia, visto que foi a partir desses fatos que se iniciou toda uma reestruturação no mercado de agências.

## Integrantes

* Bárbara Bruna D'Áustole Gelape
* Douglas Fernandes de Carvalho Jardim
* Patrick Robaina Magalhães
* Simone Antunes da Cruz Macedo
* Thomas Henrique Lousada
* Valéria Aparecida Santos

## Professor

* Juliana Amaral Baroni 

Documentação

1. Introdução
2. Participantes do processo de negócio
3. Modelagem do processo de negócio
4. Projeto da arquitetura de dados da solução proposta
5. Relatórios analíticos
6. Indicadores de desempenho
7. Conclusão

## Histórico de versões

* 0.1.1
    * CHANGE: Atualização da documentação. Código permaneceu inalterado.
* 0.1.0
    * Implementação da funcionalidade X pertencente ao processo P.
* 0.0.1
    * Trabalhando na modelagem do processo de negócio.

