# Artefatos do projeto

Liste os artefatos produzidos, com suas localizações e descrição do conteúdo.


* `/processos` - Pasta com os modelos de processo de negócio.
* `/dados ` - Pasta com os modelos de dados.

