# Lista dos processos de negócio do sistema

* login.bpmn - Processo de login.
* agendar.bpmn - Processo de agendamento.
* entregar.bpmn - Processo de entrega.


